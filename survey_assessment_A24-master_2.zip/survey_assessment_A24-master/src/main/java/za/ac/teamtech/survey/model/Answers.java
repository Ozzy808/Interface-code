/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.teamtech.survey.model;

/**
 *
 * @author RONALD
 */
public class Answers {
    private int ans1;
    private int ans2;
    private int ans3;
    private int ans4;

    public Answers(int ans1, int ans2, int ans3, int ans4) {
        this.ans1 = ans1;
        this.ans2 = ans2;
        this.ans3 = ans3;
        this.ans4 = ans4;
    }

    public Answers() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    /**
     * @return the ans1
     */
    public int getAns1() {
        return ans1;
    }

    /**
     * @param ans1 the ans1 to set
     */
    public void setAns1(int ans1) {
        this.ans1 = ans1;
    }

    /**
     * @return the ans2
     */
    public int getAns2() {
        return ans2;
    }

    /**
     * @param ans2 the ans2 to set
     */
    public void setAns2(int ans2) {
        this.ans2 = ans2;
    }

    /**
     * @return the ans3
     */
    public int getAns3() {
        return ans3;
    }

    /**
     * @param ans3 the ans3 to set
     */
    public void setAns3(int ans3) {
        this.ans3 = ans3;
    }

    /**
     * @return the ans4
     */
    public int getAns4() {
        return ans4;
    }

    /**
     * @param ans4 the ans4 to set
     */
    public void setAns4(int ans4) {
        this.ans4 = ans4;
    }
    
    
    
}
