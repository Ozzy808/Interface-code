/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package za.ac.teamtech.survey.daoInterface;

/**
 *
 * @author RONALD
 */
public interface favFoodDaoInterface {
    public boolean favFood(String favMeal);
    public double pizzaFav();
    public double pastaFav();
    public double papWorsFav();
}
